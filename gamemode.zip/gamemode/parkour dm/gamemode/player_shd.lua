function GM:CanPlayerEnterVehicle( player, vehicle, role )
	return false
end

function GM:PlayerNoClip( pl, on )
	return false
end

function GM:PlayerSpawnProp(ply, model, ent)
	return false
end

function GM:PlayerSpawnNPC(ply, ent)
	return false
end

function GM:PlayerSpawnRagdoll(ply, model, ent)
	return false
end

function GM:PlayerSpawnVehicle(ply, ent)
	return false
end

function GM:PlayerSpawnEffect(ply, model)
	return false
end

function GM:PlayerSpawnObject(ply, model, skin)
	return false
end

function GM:PlayerSpawnSENT(ply, class)
	return false
end

function GM:PlayerSpawnSWEP(ply, weapon, swep)
	return false
end

